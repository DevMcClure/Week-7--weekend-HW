import unittest
from tests.record_store_test import *

if __name__ == "__main__":
    unittest.main()
